

<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-4">
        <div class="text-center mb-5">
            <h2 class="fw-bold text-white py-3 rounded"
                style="background: linear-gradient(90deg, #0A7ABF, #25A6D9); box-shadow: 0 4px 8px rgba(0,0,0,0.2);">
                Asignar Permisos a Usuarios
            </h2>
        </div>

        <form action="<?php echo e(route('usuarios.permisos.guardar')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mb-5 shadow" style="border: none; background-color: #F2F2F2;">
                    <div class="card-header text-white d-flex justify-content-between align-items-center"
                        style="background: linear-gradient(90deg, #25A6D9, #0A7ABF); font-size: 1.1rem;">
                        <span><i class="fas fa-user-circle me-2"></i><strong><?php echo e($usuario->name); ?></strong> -
                            <?php echo e($usuario->email); ?></span>
                        <span class="badge bg-white text-primary px-3 py-2 shadow-sm">ID: <?php echo e($usuario->id); ?></span>
                    </div>

                    <div class="card-body">
                        <div class="row g-3">
                            <?php $__currentLoopData = $modulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $permisoInactivo = in_array(
                                        $modulo,
                                        $usuario->permisos->pluck('modulo')->toArray(),
                                    );
                                    $moduloNombre = ucfirst(str_replace('_', ' ', $modulo));
                                ?>

                                <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                                    <div class="border rounded p-3 text-center shadow-sm"
                                        style="background-color: white; transition: all 0.3s ease; border-left: 5px solid <?php echo e(!$permisoInactivo ? '#6EBF49' : '#ccc'); ?>">
                                        <label class="form-label d-block mb-2 text-dark" style="font-weight: 600;">
                                            <?php echo e($moduloNombre); ?>

                                        </label>
                                        <div class="form-check form-switch d-flex justify-content-center">
                                            <input class="form-check-input" type="checkbox"
                                                name="permisos[<?php echo e($usuario->id); ?>][]" value="<?php echo e($modulo); ?>"
                                                style="border-color: #6EBF49;" <?php echo e(!$permisoInactivo ? 'checked' : ''); ?>>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="d-flex justify-content-center gap-3 mb-5">
                <button type="submit" class="btn text-white px-4 py-2 shadow" style="background-color: #6EBF49;">
                    <i class="fa fa-save me-1"></i> Guardar Permisos
                </button>
                <a href="<?php echo e(route('usuarios.index')); ?>" class="btn btn-outline-danger px-4 py-2 shadow">
                    <i class="fa fa-times me-1"></i> Cancelar
                </a>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php if(session('success')): ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: '¡Permisos actualizados!',
                text: '<?php echo e(session('success')); ?>',
                confirmButtonColor: '#25A6D9',
                confirmButtonText: 'Aceptar',
                showClass: {
                    popup: 'animate__animated animate__fadeInDown'
                },
                hideClass: {
                    popup: 'animate__animated animate__fadeOutUp'
                }
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Boticas_DTotyFarma\resources\views/usuarios/permisos.blade.php ENDPATH**/ ?>